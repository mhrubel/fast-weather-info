<?php

namespace FastWeatherInfo\Models;

use WPDrill\Models\PostType;

class Post extends PostType
{
    public static ?string $postType = "post";
}
