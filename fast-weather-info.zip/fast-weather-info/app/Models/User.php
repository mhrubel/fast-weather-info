<?php

namespace FastWeatherInfo\Models;

use WPDrill\Models\Model;

class User extends Model
{
    protected static $table = 'users';
}
