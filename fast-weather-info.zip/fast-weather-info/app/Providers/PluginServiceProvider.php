<?php

namespace FastWeatherInfo\Providers;

use WPDrill\ServiceProvider;

class PluginServiceProvider extends ServiceProvider
{

    public function register(): void
    {
        // TODO: Implement register() method.
    }

    public function boot(): void
    {
        // TODO: Implement boot() method.
    }
}
