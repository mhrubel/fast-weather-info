<?php

namespace FastWeatherInfo\Rest\Middleware;

class WPDrillMiddleware
{
	public function handle()
	{
		return true;
	}
}