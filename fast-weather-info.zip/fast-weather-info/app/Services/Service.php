<?php

namespace Rvxp\Services;

class Service
{
    add_action('widgets_init', 'register_weather_widget');
}
